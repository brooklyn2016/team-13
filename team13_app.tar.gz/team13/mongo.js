// mongo.js
//var should = require('should');
var mongo = require('mongodb');
var monk = require('monk');
var db = monk('localhost:27017/test');
//should.exists(db);

	
