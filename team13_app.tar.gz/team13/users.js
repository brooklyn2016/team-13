var express = require('express');
var router = express.Router();
//var users = db.get('users');
/*
app.get('/userlist',function(req, res) {
	var db = req.db;
	var users = db.get('users');
	users.find({},{},function(e, docs) {
		res.join(docs)
	});
});
*/
