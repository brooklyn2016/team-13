//app.js
//main application

var express = require('express');
//var path = require('path');
//var favicon = require('serve-favicon');
//var logger = require('morgan');
//var cookieParser = require('cookie-parser');
//var bodyParser = require('body-parser');
//var passport = require('passport');
//var mongo = require('./mongo');

var mongo = require('mongodb');

var db = require('monk')('127.0.0.1:27017/test');

var MongoClient = require('mongodb').MongoClient;
var url = 'mongodb://localhost:27017/test';
//debugger;
MongoClient.connect(url, function(err, db) {
	console.log("surprise");
	if(err) {
		console.log("unable to connect");
	} else {
		console.log("connected");
		console.log(db);
	}
});

console.log(url);
var app = express();


//var routes = require('./routes/index');
//var users = require('./routes/users');

var app = express();
app.use(express.static('public'));
app.use(function(req, res, next) {
	req.db = db;
	next();
});

app.get('/', function (req, res) {
	res.sendfile('views/sitemap.html');
});



app.get('/login', function(req, res) {
  res.sendfile('views/login/login.html');
});

app.get('/questions', function(req, res) {
  res.sendfile('views/questions/questions.html');
});
app.get('/question2', function(req, res) {
  res.sendfile('views/questions/question2.html');
});

app.get('/AllCountriesReport', function(req, res) {
  res.sendfile('views/AllCountriesReport.html');
});
app.get('/ByCountryReport', function(req, res) {
  res.sendfile('views/ByCountryReport.html');
});
app.get('/Choose', function(req, res) {
  res.sendfile('views/Choose.html');
});
app.get('/HQ', function(req, res) {
  res.sendfile('views/HQ.html');
});

app.get('/userlist',function(req, res) {
	var Mdb = req.db;
	//var users = dbUsers.get('users');
	res.send(Mdb);
	//console.log(users);
	//Mdb.driver._native.command(
	//	{"listCollections":1},
	//	function(err, result) {
	//		console.log(result.cursor.firstBatch.map(function(el) {
	//			return el.name;
	//	}))

	//});
	Mdb.collectionNames(function(e, docs) {
		res.send(docs);
	});
});
app.listen(3000, function () {
  console.log('Example app listening on port 3000!');
});


