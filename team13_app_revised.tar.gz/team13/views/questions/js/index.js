var server ='ec2-107-20-10-161.compute-1.amazonaws.com';

var resQuestions = '/questions';

var resAssessments = '/assessments';

var resUsers = '/users';

var resReports = '/reports';